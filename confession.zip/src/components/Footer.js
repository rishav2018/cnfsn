import React from 'react'

export default function Footer() {
  return (
    <div className="container ">
        <div className="footer-wrapper">

            <span>
          <i>    kopee wright jajajajaja.com</i>
            </span>
        </div>
    </div>
  )
}
