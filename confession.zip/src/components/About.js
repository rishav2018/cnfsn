import React from 'react'

export default function About() {
  return (
    <div className='container confession-body'>
    <div className="confession-card-wrappers">
        <h1 className='mt-5 mx-5 mb-5'>Your mom lmao
        </h1>
    </div>
    </div>
  )
}
